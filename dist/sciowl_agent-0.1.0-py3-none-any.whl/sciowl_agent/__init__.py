"""SciOWL scientific agent reference implementation."""
__version__ = "0.1.0"

